## Config

All config files must be in this folder. If there is no option to set this folder directly, it has to be hardlinked.